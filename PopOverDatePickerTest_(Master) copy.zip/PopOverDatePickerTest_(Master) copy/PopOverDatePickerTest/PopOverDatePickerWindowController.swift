//
//  PopOverDatePickerWindowController.swift
//  PopOverDatePickerTest
//
//  Created by jim kitchen on 2021-10-28.
//

import Cocoa

class PopOverDatePickerWindowController: NSWindowController {
    
//  =====================================================================
//  MARK: - Control the cascade the window position to "OFF".
//  =====================================================================

    required init?(coder: NSCoder) {
      super.init(coder: coder)
      shouldCascadeWindows = false
    }

//  =====================================================================
//  MARK: - Default Methods
//  =====================================================================

    func applicationDidFinishLaunching(_ aNotification: Notification) {
    }

    override func windowDidLoad() {
      super.windowDidLoad()
    }

}   //  <=== End of (class PopOverDatePickerWindowController: NSWindowController)
