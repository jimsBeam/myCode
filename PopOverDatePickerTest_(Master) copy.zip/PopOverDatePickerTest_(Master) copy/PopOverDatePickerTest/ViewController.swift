//
//  ViewController.swift
//  PopOverDatePickerTest
//
//  Created by jim kitchen on 2021-10-28.
//

import Cocoa
import AppKit



    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
    //  MARK: - EXTENSIONS
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================


    //  To observe when a (NOTIFICATION) changes.
    //  You need first to define the identifier for the notification.
    //  This is done at global level, outside any class dedinition :
    extension  Notification.Name {
        public static let kMyNotification = Notification.Name("theNotificationNameForThisApplication")
    }

    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================


class ViewController: NSViewController, NSDatePickerCellDelegate {
    
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
    //  MARK: - Identify the Outlets.
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
        
        @IBOutlet weak var datePicker: PopDatePicker!
        
        @IBOutlet weak var showPopoverButton: NSButton!
        
        @IBOutlet weak var showTheSelectedDateLabel: NSTextField!
        
        @IBOutlet weak var messageBox: NSBox!
        
        @IBOutlet weak var messageLabel: NSTextField!
        
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
    //  MARK: - Identify the (Popover Status Traffic Light Images).
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
    
    
        /// Identify the Popover Calendar Status Images
        /// The images are laid on top of each other in the (VIEW).
        /// Left Side Images
        
        @IBOutlet weak var theLeftPopoverCalendarIconIdleImage: NSImageView!
        
        @IBOutlet weak var theLeftPopoverCalendarIconAvailableImage: NSImageView!
        
        @IBOutlet weak var theLeftPopoverCalendarIconAwayImage: NSImageView!
        
    
    
        
        @IBOutlet weak var theRightPopoverCalendarIconIdleImage: NSImageView!
        
        @IBOutlet weak var theRightPopoverCalendarIconAvailableImage: NSImageView!
        
        @IBOutlet weak var theRightPopoverCalendarIconAwayImage: NSImageView!
    
    
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
    //  MARK: - Identify the current date.
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
    /// The following (constants) are known as a (Local Constants).
    /// These (constants) are ony avialble to be used within the originating
    /// class, and (no where oustside) of the class, such as another view controller.

        let now = Date()
        
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
    //  MARK: - Format the current date.
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
        
        let formatterDate: DateFormatter = {
            
            let _formatter = DateFormatter()
            
            /// Show the (Date) with (Weekday / Month / Day / Year).
            _formatter.dateStyle = .full
            /// Show the (Date) wiith (Month / Day / Year).
            //_formatter.dateFormat = "MMMM dd, YYYY"
            return _formatter
            
        }()     //  <=== End of "let formatterDate: DateFormatter ="
    
    
    
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
    //  MARK: - 🔴🔴🔴🔴🔴 VIEW DID LOAD 🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================

        override func viewDidLoad() {
            super.viewDidLoad()
            
            datePicker.dateValue = Date()
            
            datePicker.shouldShowPopover = { [weak self] in
                return self?.showPopoverButton.state == .on
            }
            
            datePicker.delegate = self
        
        
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
    //  MARK: - Identify (datePicker) information.
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
        
        let dateFormatter = DateFormatter()
        //dateFormatter.dateStyle = .long
        //dateFormatter.timeStyle = .long
        //dateFormatter.dateStyle = .full
        //dateFormatter.timeStyle = .full
        dateFormatter.dateStyle = .short
        dateFormatter.timeStyle = .short
        
        /// Select the format required by the user location.
        dateFormatter.locale = Locale(identifier: "en_US")
        
        /// Select the format required by the application for display.
        dateFormatter.setLocalizedDateFormatFromTemplate("MMMM dd, YYYY")
        
        let dateTime = dateFormatter.string(from: now)
        print("\"The datePicker states the current date = \(dateTime)")
        
        let locale = NSLocale.autoupdatingCurrent
        let code = locale.languageCode!
        let language = locale.localizedString(forLanguageCode: code)!
        
        /// Prints (English) for locale en_US, (français" for fr_FR).
        print("\"The datePicker states the selected language = \(language)")
        
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
    //  MARK: - Initialize the Idle, Away, and Available Images.
    /// The images are set to the default views when the application activates the
    /// "Add649NumbersTab" and the images change status when a specific action occurs.
    ///
    /// The (Idle) view is the default view, which is (LIGHT YELLOW).
    /// The (alert) view is the (RED) something is wrong image.
    /// The (availble) view is (GREEN) good to go image.
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
        
        /// The Left Popover Calendar Activity Images
        theLeftPopoverCalendarIconIdleImage?.isHidden = false
        theLeftPopoverCalendarIconAvailableImage?.isHidden = true
        theLeftPopoverCalendarIconAwayImage?.isHidden = true
        
        /// The Right Popover Calendar Activity Images
        theRightPopoverCalendarIconIdleImage?.isHidden = false
        theRightPopoverCalendarIconAvailableImage?.isHidden = true
        theRightPopoverCalendarIconAwayImage?.isHidden = true
        
    //  ============================================================
    //  MARK: - Default User Preferences Notifications
    //  ============================================================

        /// Call the "resetUserDefaultsNotificationRequest" function to reset the "Application Defaults".
        NotificationCenter.default.addObserver(self, selector: #selector(self.resetUserDefaultsNotificationRequest),
                            name: NSNotification.Name(rawValue: "theUserWantsToResetTheApplicationDefaults"),
                            object: nil)
    
    }   //  <=== End of (override func viewDidLoad())
    
    
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
    //  MARK: - Identify the (Selected Date Cell) from the (Popover)
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
        
        
        func datePickerCell(_ datePickerCell: NSDatePickerCell,
            validateProposedDateValue proposedDateValue: AutoreleasingUnsafeMutablePointer<NSDate>,
            timeInterval proposedTimeInterval: UnsafeMutablePointer<TimeInterval>?) {
            
            let date1 = proposedDateValue.pointee
            let dateString = formatterDate.string(from: date1 as Date)
            
            // Print the (Selected Date) picked in the (Popover).
            print(dateString)
            
            // Place the (Selected Date) picked in the (Popover) in the (Show Selected Date Label).
            showTheSelectedDateLabel.stringValue = dateString
            
            
            //  ================================================================================
            //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            //  ================================================================================
            //  MARK: - Grab and format the selected date from the date picker.
            /// Identify the required comparison date format for the (checkThePopoverDateTimeStamp) function.
            /// NOTE: The (checkThePopoverDateTimeStamp) function requires the date format to be
            /// set as (yyyy-MM-dd HH:mm:ss) and not as (MMM dd, YYYY).
            //  ================================================================================
            //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            //  ================================================================================
            
            let checkTheDateToTestFormatter = DateFormatter()
            checkTheDateToTestFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
            
            let dateToCheck = proposedDateValue.pointee
            let theSelectedDateToCheck = checkTheDateToTestFormatter.string(from: dateToCheck as Date)
            print("The NSDatePicker states the selected date to check :: \(theSelectedDateToCheck)")


    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
    //  MARK: - Verify the (Selected date) from the (Popover)
    //  ================================================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ================================================================================
        
        if(theSelectedDateToCheck != "") {
            
            if (checkThePopoverDateTimeStamp(date:theSelectedDateToCheck) == false) {
                
                //  ============================================================
                //  MARK: - Selected Date Less Than Todays Date Code
                /// The application is (here) because the (selectedDate) is less than the (Current Date and Time).
                
                /// This indicates the (DrawDate) occurred in the past
                /// The application can use this (psst date) to search the database for previous lottery
                /// dates from 1982 to look for previous winning numbers or to determine whether a
                /// winning (Draw Date) occurred, by checking the calendar dates in the tableViews
                /// (Draw Date) column.
                //  ============================================================
                //  MARK: - Change the (MESSAGE LABEL TO INDICATE A VALID DATE).
                //  ============================================================
                
                print("The NSDatePicker states the selected date to send = \(theSelectedDateToCheck)")
                /// Send a notification to "Add649NumberController" to update the selected calendar date ...
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "displayCorrectSelectedDate"),
                                                    object: theSelectedDateToCheck)
                
                
                
                /// Cleanse previous displayed message.
                messageLabel.stringValue = ""
                /// Insert the (New Message).
                messageLabel.stringValue = "Valid Draw Date to Check"
                
                //  ============================================================
                //  MARK: - Change the (MESSAGE LABEL FONT SIZE).
                //  ============================================================
                /// Change the (Font Size) to accommodate the text message with a larger font.
                /// NOTE: This code requires (macOS 10.15) or higher.
                /// Code must be written to accomodate previous macOS versions.
                /// For the moment, the (Font Size) is set in (IB), compared to the (Font Size) of (13).
                
                if #available(macOS 10.15, *) {
                    
                    messageLabel?.font = messageLabel.font?.withSize(20)
                    
                } else {
                    
                    // Fallback on earlier versions
                    // Requires proper code here.
                    
                }   //  <=== End of "if #available(macOS 10.15, *)"
                
                
                //  ============================================================
                //  MARK: - Change the (MESSAGE LABEL FONT COLOUR).
                //  ============================================================
                
                /// Since the (Selected Date) is before (Todays Date) make the (MESSAGE LABEL Text Colour GREEN).
                messageLabel?.textColor = NSColor.systemGreen // <===  System Green
                
                print ("The checkThePopoverDateTimeStamp Function wants me to do something since the selected date is before the current date.")
                
                
                //  ============================================================
                //  MARK: - Change the (SELECTED DATE LABEL FONT COLOUR).
                //  ============================================================
                
                /// Since the (Selected Date) is before (Todays Date) make the (SELECTED DATE LABEL Text Colour GREEN).
                showTheSelectedDateLabel?.textColor = NSColor.systemGreen // <===  System Green
                
                
                //  ============================================================
                //  MARK:  - Update the (Status Traffic Light Images)
                //  Since the (SELECTED DATE) is less than (TODAYS DATE) make
                //  the (TRAFFIC LIGHTS) react accordingly, by activating the
                //  (AVAILABLE IMAGE) and disabling the (IDLE AND AWAY IMAGES).
                //  ============================================================
                
                /// The Left Popover Calendar Activity Images:
                theLeftPopoverCalendarIconIdleImage?.isHidden = true
                theLeftPopoverCalendarIconAvailableImage?.isHidden = false
                theLeftPopoverCalendarIconAwayImage?.isHidden = true
                
                /// The Right Popover Calendar Activity Images:
                theRightPopoverCalendarIconIdleImage?.isHidden = true
                theRightPopoverCalendarIconAvailableImage?.isHidden = false
                theRightPopoverCalendarIconAwayImage?.isHidden = true
                
                
                //  ============================================================
                //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                //  ============================================================
                //
                //  MARK: - Send Notifications
                //
                //  ============================================================
                //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                //  ============================================================
                
                
//                /// Prepare the "selectedDate" to be sent to the "Add649NumberController" with a date format it can understand ...
//                let theOtherDateFormatter = DateFormatter()
//                theOtherDateFormatter.dateFormat = "MMMM dd, YYYY"
//
//
////                /// Convert the date to the required format ...
//                let theCorrectSelectedDateToSend = theOtherDateFormatter.string(from: datePicker.dateValue)
//                print("The NSDatePicker states the selected date to send = \(theCorrectSelectedDateToSend)")
//
//
//                /// Send a notification to "Add649NumberController" to update the selected calendar date ...
//                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "displayCorrectSelectedDate"),
//                                                    object: theCorrectSelectedDateToSend)
                
                
                //  ============================================================
                //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                //  ============================================================
                
                
            } else {
                
                
                //  ============================================================
                //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                //  ============================================================
                //  MARK:  - "Selected Date After Today's Date Code"
                /// The application is (here) because the (selectedDate) is greater than the (Current Date and Time).
                ///
                /// This indicates the Lottery "DrawDate" cannot occur.
                ///
                /// Therefore the application will present a warning window or sheet to the (user) to choose
                /// another (SELECTED DATE) from the (datePicker).
                //  ============================================================
                //  MARK: - Change the (MESSAGE LABEL TO INDICATE A INVALID DATE).
                //  ============================================================
                
                /// Cleanse previous message.
                messageLabel.stringValue = ""
                /// Insert the (warning) message.
                messageLabel.stringValue = "Invalid Draw Date to Check"
                
                //  ============================================================
                //  MARK: - Change the (MESSAGE LABEL FONT SIZE).
                //  ============================================================
                /// Change the (Font Size) to accommodate the text message with a larger font.
                /// NOTE: This code requires (macOS 10.15) or higher.
                /// Code must be written to accomodate previous macOS versions.
                /// For the moment, the (Font Size) is set in (IB), compared to the (Font Size) of (13).
                
                if #available(macOS 10.15, *) {
                    
                    messageLabel?.font = messageLabel.font?.withSize(20)
                    
                } else {
                    
                    // Fallback on earlier versions
                    // Code needs to be written.
                    
                }   //  <=== End of "if #available(macOS 10.15, *)"
                
                
                //  ============================================================
                //  MARK: - Change the (MESSAGE LABEL FONT COLOUR).
                //  ============================================================
                
                messageLabel?.textColor = NSColor(red: 1.00, green: 0.00, blue: 0.00, alpha: 0.80) // <===  Darker RED
                
                print ("The checkThePopoverDateTimeStamp Function wants me to do something since the selected date is after the current date.")
                
                //  ============================================================
                //  MARK: - Change the (SELECTED DATE LABEL FONT COLOUR).
                //  ============================================================
                
                showTheSelectedDateLabel?.textColor = NSColor(red: 1.00, green: 0.00, blue: 0.00, alpha: 0.80) // <===  Darker RED
                
                //  ============================================================
                //  MARK:  - Update the (Status Traffic Light Images)
                //  ============================================================
                
                /// The Left Popover Calendar Activity Images
                theLeftPopoverCalendarIconIdleImage?.isHidden = true
                theLeftPopoverCalendarIconAvailableImage?.isHidden = true
                theLeftPopoverCalendarIconAwayImage?.isHidden = false
                
                /// The Right Popover Calendar Activity Images
                theRightPopoverCalendarIconIdleImage?.isHidden = true
                theRightPopoverCalendarIconAvailableImage?.isHidden = true
                theRightPopoverCalendarIconAwayImage?.isHidden = false
                
                
                //  ============================================================
                //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                //  ============================================================
                //
                //  MARK: - Send Notifications
                //
                //  ============================================================
                //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                //  ============================================================
                
                
                /// Prepare the "selectedDate" to be sent to the "Add649NumberController" with a date format it can understand ...
                let theOtherDateFormatter = DateFormatter()
                theOtherDateFormatter.dateFormat = "MMMM dd, YYYY"
                
                
                /// Convert the date to the required format ...
                let theWrongSelectedDateToSend = theOtherDateFormatter.string(from: datePicker.dateValue)
                print("The NSDatePicker states the selected date to send = \(theWrongSelectedDateToSend)")
                
                
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "displayWrongSelectedDate"),
                                                    object: theWrongSelectedDateToSend)
                
                
                //  ============================================================
                //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
                //  ============================================================
                
                
            }   //  <=== End of "if (checkThePopoverDateTimeStamp(date:theSelectedDateToCheck) == false)"
            
            
        } else {
            
            
            //  ================================================================================
            //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            //  ================================================================================
            //  MARK: We are here because the (SELECTED DATE) was empty (nil)
            //  ================================================================================
            //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            //  ================================================================================
            
            /// The Left Popover Calendar Activity Images
            theLeftPopoverCalendarIconIdleImage?.isHidden = true
            theLeftPopoverCalendarIconAvailableImage?.isHidden = true
            theLeftPopoverCalendarIconAwayImage?.isHidden = false
            
            /// The Right Popover Calendar Activity Images
            theRightPopoverCalendarIconIdleImage?.isHidden = true
            theRightPopoverCalendarIconAvailableImage?.isHidden = true
            theRightPopoverCalendarIconAwayImage?.isHidden = false

            print("theTransferredSelectedDate is empty")
            
            /// Bail Gracefully ...
            return
            
        }   //  <=== *** End of "if(theSelectedDate != "")" ***
        
        
    }   //  <=== End of "func datePickerCell(_ datePickerCell:"



    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
    //  MARK: - 🔴🔴🔴🔴🔴 IDENTIFY WHICH (DATE PICKER EDGE) TO SHOW THE (POPOVER) 🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
        
        
        @IBAction func preferredEdgeChanged(_ sender: NSPopUpButton) {
            
            switch sender.indexOfSelectedItem {
                
                case 0:
                    //  Place on (top)
                    datePicker.preferredPopoverEdge = .maxY
                case 1:
                    // Place on (bottom)
                    datePicker.preferredPopoverEdge = .minY
                case 2:
                    //  Place on (right)
                    datePicker.preferredPopoverEdge = .maxX
                case 3:
                    //  Place on (left)
                    datePicker.preferredPopoverEdge = .minX
                default:
                    // Place on (top)
                    datePicker.preferredPopoverEdge = .maxY
                    break
                    
            }   //  <=== End of "switch sender.indexOfSelectedItem"
            
            
        }   //  <==+ End of "@IBAction func preferredEdgeChanged(_ sender: NSPopUpButton)"



//  MARK: ========================================================================================================================
//  MARK: ========================================================================================================================
//  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  MARK: ========================================================================================================================
//
//  MARK: - RESET THE "USER DEFAULTS" FUNCTION THROUGH THE PREFERENCE WINDOW
//
//  MARK: ========================================================================================================================
//  MARK: ========================================================================================================================
//  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  MARK: ========================================================================================================================

        @objc func resetUserDefaultsNotificationRequest() {
     
            print("Resetting Application Defaults")
 
            //  ============================================================
            //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            //  ============================================================
            //  MARK: - NOTE: Reset the "Application's User Defaults"
            //  ============================================================
            //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            //  ============================================================
            /// Identify "My Application Bundle ID"

            let bundleID = Bundle.main.bundleIdentifier
            print("My bundle ID = \(String(describing: bundleID))")

            /// The following lines of code allow the "extension UserDefaults" in this file to reset the
            /// "Application's User Defaults" to the "ORIGINAL" values.
            if let bundleID = Bundle.main.bundleIdentifier {
                UserDefaults.standard.removePersistentDomain(forName: bundleID)
            } //  <=== End of "if let bundleID = Bundle.main.bundleIdentifier"

            //  ============================================================
            //  ============================================================

        }  //  <=== End of "@objc func resetUserDefaultsNotificationRequest()"
    
    
    }   //  <=== End of "class PopDatePickerViewController: NSViewController  , NSDatePickerCellDelegate"


//  MARK: ========================================================================================================================
//  MARK: ========================================================================================================================
//  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  MARK: ========================================================================================================================
//  MARK: - 🔴🔴🔴🔴🔴 COMPARE THE (CALENDAR DATE) WITH (CHECK THE TIME STAMP) 🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴
//  MARK: ========================================================================================================================
//  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  MARK: ========================================================================================================================
//  MARK: ========================================================================================================================
        
        //  ================================================================================
        //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //  ================================================================================

        //  MARK: - Compare Dates with "checkThePopoverDateTimeStamp" function

        /// This function compares the Current Date [ Date() ] with the (Selected Date) from the (datePicker) to determine
        /// whether the (slectedDate) is a date before the (Current Date) or whether the (selectedDate) occurs after the (Current Date).
        ///
        /// The purpose of this function is to inform the (user) the (selectedDate) cannot be used in the application when this event
        /// occurs after the (Current Date). The application is designed to alert the (user) to select a date before the (Current date)
        ///
        /// The application will also employ (a RED traffic light) to alert the (user) to change the (selectedDate).
        
        //  ================================================================================
        //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //  ================================================================================

          func checkThePopoverDateTimeStamp(date: String!) -> Bool {
              
              print("checkThePopoverDateTimeStamp called")
              
              let dateFormatter: DateFormatter = DateFormatter()
              dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
              dateFormatter.locale = Locale(identifier:"en_US_POSIX")
              let datecomponents = dateFormatter.date(from: date)
              
              let now = Date()
              
              if (datecomponents! >= now) {
                  
                  print ("The selected date is after the current date ...")
                  return true
                  
              } else {
                  
                  print ("The selected date is before the current date ...")
                  return false
                  
              }   //  <=== End of "if (datecomponents! >= now)"
              
              
          } //  <=== End of "func checkThePopoverDateTimeStamp(date: String!) -> Bool"


