//
//  AppDelegate.swift
//  PopDatePicker Demo
//
//  Created by Adam Hartford on 4/22/15.
//  Copyright (c) 2015 Adam Hartford. All rights reserved.
//

import Cocoa
import SwiftUI

@available(macOS 11.0, *)
@NSApplicationMain

class AppDelegate: NSObject, NSApplicationDelegate {
    
    var preferencesController: NSWindowController?
    
    var windowController : NSWindowController!

    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
    /// Uses (enum) code and (@AppStorage")will watch (UserDefaults.standard) by default.
    ///
    /// The same would be true if we had used the older method:
    /// UserDefaults.standard.set(@someThingToStore, forKey: someKeyName)
    /// Important: @AppStorage writes your data to UserDefaults, which is not secure storage.
    ///
    /// As a result, you should not save any personal data using @AppStorage, because
    /// it is easy to extract the information.
    ///
    /// AppStorage Note:
    /// (@AppStorage) is a convenient way to save and read variables from (UserDefaults)
    /// and use them in the same way as (@State) properties. It can be seen as a
    /// (@State) property. which is automatically saved to (and read from) (UserDefaults).
    ///
    /// This is a persistent storage provided by SwiftUI.
    /// This code will persist the email across app launches.
    /// With pure SwiftUI code, we can now persist such data without using UserDefaults at all.
    ///
    /// But if you do want to access the underlying data, it is no secret that the wrapper is
    /// using UserDefaults. For example, you can still update using UserDefaults.standard.set(...),
    /// and the benefit is that AppStorage observes the store, and the SwiftUI view will
    /// update automatically.
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
        
        @AppStorage("appearance") var appearance = AppAppearance.system
    
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================

        var window: NSWindow!
        //var systemMode: String    // <=== Fails with this line of code
    
        var systemMode = "system"   //  <=== Application needs this to be initialized
    
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
    /// Identify new menu item outlets for "Dark, Light,and System Mode"
        @IBOutlet weak var darkModeMenuItem: NSMenuItem!
        @IBOutlet weak var lightModeMenuItem: NSMenuItem!
        @IBOutlet weak var systemModeMenuItem: NSMenuItem!
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
    //  MARK: - Identify the "View" Menu Items Status
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================

        func setStoredSystemMode() {
            
            switch systemMode {
            case "dark":
                NSApp.appearance = NSAppearance(named: .darkAqua)
            case "light":
                NSApp.appearance = NSAppearance(named: .aqua)
            default:
                NSApp.appearance = nil
            }
        
            showSelectedModeInMenu()
        
        }   //  <=== End of "func setStoredSystemMode()"

    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
        
        func showSelectedModeInMenu() {
            
            switch systemMode {
            
            case "dark":
                darkModeMenuItem.state = .on
                lightModeMenuItem.state = .off
                systemModeMenuItem.state = .off
            case "light":
                darkModeMenuItem.state = .off
                lightModeMenuItem.state = .on
                systemModeMenuItem.state = .off
            default:
                darkModeMenuItem.state = .off
                lightModeMenuItem.state = .off
                systemModeMenuItem.state = .on
            
            }    //     <=== End of "switch systemMode"
        
        }   //  <=== End of "func showSelectedModeInMenu()"
    
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
    //  MARK: - Menu Actions
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
    
        @IBAction func darkModeSelected(_ sender: Any) {
            NSApp.appearance = NSAppearance(named: .darkAqua)
            systemMode = "dark"
            showSelectedModeInMenu()
        }
    
        @IBAction func lightModeSelected(_ sender: Any) {
            NSApp.appearance = NSAppearance(named: .aqua)
            systemMode = "light"
            showSelectedModeInMenu()
        }
    
        @IBAction func systemModeSelected(_ sender: Any) {
            NSApp.appearance = nil
            systemMode = "system"
            showSelectedModeInMenu()
        }

    
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
    //  MARK: - applicationDidFinishLaunching
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
    
        func applicationDidFinishLaunching(_ aNotification: Notification) {
            // Insert code here to initialize your application
 
            
            /// An (EXTENSION) for (NOTIFICATIONS).
            let nc = NotificationCenter.default
            nc.post(name: .kMyNotification, object: nil)
            
            /// (SYSTEM MODE) to (CHANGE DARK MODE / LIGHT MODE)
            setStoredSystemMode()
        }

    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
    //  MARK: - applicationWillTerminate
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
        
        func applicationWillTerminate(_ aNotification: Notification) {
            // Insert code here to tear down your application
        }
    
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
    //  MARK: - This is the "NORMAL" shutdown the application code.
    /// This function shuts down the application after the last window is closed.
    /// This prevents the application form running continuously when the last window is closed.
        //func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        //    return true
        //}
    
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
    //  MARK: - The "NEW" shutdown "Alert" window application code.
    /// This function shuts down the application after the last window is closed. with a twist.
    /// This prevents the application form running continuously when the last window is closed.
    /// The code presents the user with a Alert Panel asking the User if the User really wants
    /// to quit the application, and asks the User whether they want to see the Alert panel
    /// again with (Suppression Code).
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
    
        func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
            
        /// Store the (suppression state) in (userDefaults) to (NOT ASK THIS QUESTION AGAIN).
            let userDefaultsKey = "dontAskToQuit"
        
        /// Check to see whether the (User) answered the question to not see the following code again
            if UserDefaults.standard.bool(forKey: userDefaultsKey) == false {
            
            /// We are here because the (User) did not check the answer, so show the alert message
                let alert = NSAlert()
                alert.messageText = NSLocalizedString("Time to Quit!", comment: "exit alert title")
                alert.informativeText = NSLocalizedString("Do you want to exit this application?", comment: "ask the user if they want to exit")
                alert.alertStyle = .critical
                alert.showsSuppressionButton = true
                alert.suppressionButton?.title = "Don't ask me again!"
                alert.addButton(withTitle: NSLocalizedString("Exit The Application", comment: "OK button title"))
                alert.addButton(withTitle: NSLocalizedString("No, I Shall Remain!", comment: "Cancel button title"))
                
                let response = alert.runModal()
                
                /// The "Suppression Button" checked to stop showing the "Alert".
                if let supress = alert.suppressionButton {
                    
                    let state = supress.state
                    
                    switch state {
                    
                        case NSControl.StateValue.on:
                            UserDefaults.standard.set(true, forKey: userDefaultsKey)
                        default: break
                    
                    }    //    <=== End of "switch state"
                
                }    //    <=== End of "if let supress = alert.suppressionButton'
                
                if response == .alertFirstButtonReturn {
                /// Terminate the application.
                    return .terminateNow
                } else {
                /// Cancel the termination.
                    return .terminateCancel
                }
            
            }    //     <=== End of " if UserDefaults.standard.bool(forKey: userDefaultsKey) == false"
            
            return .terminateNow
        
        }   //  <===    End of "func applicationShouldTerminate"

    
    
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
    //  MARK: - Show the Preference Window (DISABLED FOR THE MOMENT)
    //  ============================================================
    //  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  ============================================================
    
        @IBAction func showPreferences(_ sender: Any) {

        if !(preferencesController != nil) {

            let storyBoard = NSStoryboard(name: NSStoryboard.Name("Preferences"), bundle: nil)

            preferencesController = storyBoard.instantiateInitialController() as? NSWindowController
        }

            if(preferencesController != nil) {

                preferencesController!.showWindow(sender)
            }

        }    //    <=== End of "@IBAction func showPreferences(_ sender: Any)"
    
    
    
    }   //  <=== End of "class AppDelegate: NSObject, NSApplicationDelegate"

//  ============================================================
//  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  ============================================================
//  MARK: - Set "AppAppearance" ENUM
//  ============================================================
//  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  ============================================================

    /// Works with (AppStorage).
        enum AppAppearance: String {
            case dark
            case light
            case system
        }

//  ============================================================
//  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  ============================================================


