//
//  PopDatePicker.swift
//  PopOverDatePickerTest
//
//  Created by jim kitchen on 2021-10-28.
//

import AppKit

final class PopDatePicker: NSDatePicker {

    
    let controller = PopDatePickerController()
    let popover = NSPopover()
    
    /// Initialize popover to be inactive.
    var showingPopover = false
 
    /// Set the (Default) popover edge to be (TOP) when first activated.
    public var preferredPopoverEdge = NSRectEdge.maxY

    
    public var shouldShowPopover = { return true }

 
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
    //  MARK: - 🔴🔴🔴🔴🔴 AWAKE FROM NIB FUNCTION 🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
        
        
        public override func awakeFromNib() {
            
            action = #selector(PopDatePicker.dateAction)
            controller.datePicker.action = #selector(PopDatePicker.popoverDateAction)
            controller.datePicker.bind(NSBindingName.value, to: self, withKeyPath: "dateValue", options: nil)
            popover.contentViewController = controller
            
            // (semitransient) :: The system will close the popover when the user interacts with user interface
            // elements in the window containing the popover's positioning view.
            popover.behavior = .semitransient
        
        }   //  <=== End of "public override func awakeFromNib()"
        

    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
    //  MARK: - 🔴🔴🔴🔴🔴 POPOVER DATE ACTION FUNCTION 🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
       
        
        @objc func popoverDateAction() {
            
            if let bindingInfo = infoForBinding(NSBindingName.value) {
                
                printView(bindingInfo)
                //printView("The printView data = \(bindingInfo)")

                
    //            if let keyPath = bindingInfo.value(forKey: NSObservedKeyPathKey) as? String {
    //                (bindingInfo.value(forKey: NSObservedObjectKey) as AnyObject).setValue(dateValue, forKeyPath: keyPath)
    //            }
            
                
            }   //  <=== End of "if let bindingInfo = infoForBinding(NSBindingName.value)"
        
            
        }   //  <=== End of "@objc func popoverDateAction()"

    
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
    //  MARK: - 🔴🔴🔴🔴🔴 DATE ACTION FUNCTION 🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
    
    
        @objc func dateAction() {
            
            controller.datePicker.dateValue = dateValue
            
            print("The datePicker date value = \(controller.datePicker.dateValue)")
            
        }   //  <=== End of "@objc func dateAction()"

    
    
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
    //  MARK: - 🔴🔴🔴🔴🔴 MOUSE DOWN EVENT FUNCTION 🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
        
        
        public override func mouseDown(with theEvent: NSEvent) {
            _ = becomeFirstResponder()
            super.mouseDown(with: theEvent)
        
        }   //  <=== End of "ublic override func mouseDown(with theEvent: NSEvent)"

    
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
    //  MARK: - 🔴🔴🔴🔴🔴 ACTIVATE THE (FIRST RESPONDER) with the (POPOVER) 🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
        
        
        public override func becomeFirstResponder() -> Bool {
            
            if shouldShowPopover() {
                
                showingPopover = true
                controller.datePicker.dateValue = dateValue
                popover.show(relativeTo: bounds, of: self, preferredEdge: preferredPopoverEdge)
                showingPopover = false
            
            }   //  <=== End of "if shouldShowPopover()"
            
            return super.becomeFirstResponder()
        
        }   //  <=== End of "public override func becomeFirstResponder() -> Bool"

    
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
    //  MARK: - 🔴🔴🔴🔴🔴 RESIGN THE (FIRST RESPONDER) from the (POPOVER) 🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴
    //  MARK: ========================================================================================================================
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================


        public override func resignFirstResponder() -> Bool {
            
            if showingPopover {
                
                return false
                
            }   //  <=== End of "if showingPopover"
            
            popover.close()
            
            return super.resignFirstResponder()
            
        }   //  <=== End of "public override func resignFirstResponder() -> Bool'


}   //  <=== End of "final class PopDatePicker: NSDatePicker"


//  MARK: ========================================================================================================================
//  MARK: ========================================================================================================================
//  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  MARK: ========================================================================================================================
//  MARK: - 🔴🔴🔴🔴🔴 POP DATE PICKER CONTROLLER ( VIEW CONTROLLER ) 🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴
//  MARK: ========================================================================================================================
//  MARK: ========================================================================================================================
//  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  MARK: ========================================================================================================================


    class PopDatePickerController: NSViewController {
        
        /// Identify the (datePicker)
        let datePicker: NSDatePicker

        
    //  ============================================================
    //  MARK: - REQUIRED INIT
    //  ============================================================
        
        required init?(coder: NSCoder) {
            datePicker = NSDatePicker()
            super.init(coder: coder)
        
        }   //  <=== End of "required init?(coder: NSCoder)"
        
        
    //  ============================================================
    //  MARK: - OVERRIDE INIT
    //  ============================================================
        
        override init(nibName nibNameOrNil: NSNib.Name?, bundle nibBundleOrNil: Bundle?) {
            
            //  ============================================================
            //  MARK: - MAKE ROOM TO SHOW THE (DATE PICKER AND CLOCK)
            //  ============================================================
            
            /// Identify the (datePicker Frame) size and location in the (Popover).
            /// Location from lower left corner ( x , y, width , height ) in the (Popover).
            datePicker = NSDatePicker(frame: NSMakeRect(19, 19, 139, 148))
            /// Present enough room to (SHOW THE CLOCK) in the (Popover).
            /// Location from lower left corner ( x , y, width , height ) in the (Popover).
            //datePicker = NSDatePicker(frame: NSMakeRect(20, 20, 317, 186))
            
            
            //  ============================================================
            //  MARK: - CREATE A FRAME TO HUG THE (DATE PICKER AND CLOCK)
            //  ============================================================
            
            /// Create an (NSBox) to frame the (Date Picker).
            /// Location from lower left corner ( x , y, width , height ) in the (Popover).
            /// The (NSBox) hugs the (Date Picker) border (ONLY) and not the clock.
            /// The (NSBox) frame colour is set to (SYSTEM BLUE).
            let datePickerNSBoxFrameView = NSBox(frame: NSMakeRect(14, 13, 149, 159))
            
        
            /// NO ( NIB )
            super.init(nibName: nil, bundle: nil)
            
            
            /// Identify the (popoverView Frame) size and location.
            /// /// Location from lower left corner ( x , y, width , height ).s
            let popoverView = NSView(frame: NSMakeRect(0, 0, 177, 185))
            /// Present enough room to (SHOW THE CLOCK)
            //let popoverView = NSView(frame: NSMakeRect(20, 20, 310, 186))
            
            /// Show the (datePicker) with or without the (CLOCK)
            /// The following code is the (DEFAULT STYLE) to show the (DATE PICKER and the CLOCK).
            /// The clock is hidden from view with the code above with (NSMakeRect).
            datePicker.datePickerStyle = .clockAndCalendar
            
            //  ============================================================
            //  MARK: - ADD DATE PICKER NSBOX PROPERTIES
            //  ============================================================
            
            /// The type of (NSBox).
            datePickerNSBoxFrameView.boxType = .custom
            
            /// Remove the (NSBox Title).
            datePickerNSBoxFrameView.title = ""
            
            /// Create a (NSBox Border Type).
//            datePickerNSBoxFrameView.borderType = .lineBorder     //  <=== (Depreciated in macOS 10.15)
            
            /// Create a (NSBox Border Width).
            datePickerNSBoxFrameView.borderWidth = 4
            
            ///Set the (NSBox Border Colour).
            datePickerNSBoxFrameView.borderColor = NSColor.systemBlue
            
            /// Set the (NSBox Fill Colour)     <=== Available but not in use.
            //datePickerNSBoxFrameView.fillColor = NSColor.gridColor
            
            
            //  ============================================================
            //  MARK: - ADD DATE PICKER PROPERTIES
            //  ============================================================
            
            /// Draw the (datePicker Background colour) which makes the (background colour darker).
            //datePicker.drawsBackground = false    //  <=== Transparent
            datePicker.drawsBackground = true       //  <=== Darker Background
            
            /// Set the (datePicker Background Colour) to (Black)
            datePicker.backgroundColor = NSColor.gridColor
            
            /// Set the (datePicker Text Colour) to (White)
            datePicker.textColor = NSColor.white
            
            /// Identify the (datePickerCell)
            let cell = datePicker.cell as? NSDatePickerCell
            
            /// Turn off the (datePicker Bezelled Frame)
            cell?.isBezeled = false
            
            /// Identify the (datePicker Cell Selection)
            cell?.sendAction(on: NSEvent.EventTypeMask(rawValue: UInt64(Int(NSEvent.EventType.leftMouseDown.rawValue))))
            
            
            //  ============================================================
            //  MARK: - ADD DATE PICKER AND NSBOX FRAME TO THE POPOVER VIEW
            //  ============================================================
            
            /// Add the (datePickerNSBoxFrameView) to the (popoverView)
            popoverView.addSubview(datePickerNSBoxFrameView)
            
            /// Add the (datePicker) to the (popoverView)
            popoverView.addSubview(datePicker)
            
            /// Present the (popoverView)
            view = popoverView
            
            
        }   //  <=== End of "override init(nibName nibNameOrNil: NSNib.Name?, bundle nibBundleOrNil: Bundle?)"
        
        
    }   //  <=== End of "class PopDatePickerController: NSViewController"
