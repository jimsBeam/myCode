//
//  PreferencesLoadableView.swift
//  PopOverDatePickerTest
//
//  Created by jim kitchen on 2021-10-29.
//

import Cocoa


protocol PreferencesLoadableView: AnyObject {
    var preferencesMainView: NSView? { get set }
    func load(fromNIBNamed nibName: String) -> Bool
    func add(toView parentView: NSView)
}


extension PreferencesLoadableView where Self: NSView {
    
    func load(fromNIBNamed nibName: String) -> Bool {
        
        var nibObjects: NSArray?
        let nibName = NSNib.Name(stringLiteral: nibName)
        
        if Bundle.main.loadNibNamed(nibName, owner: self, topLevelObjects: &nibObjects) {
            
            guard let nibObjects = nibObjects else { return false }
            
            let viewObjects = nibObjects.filter { $0 is NSView }
            
            if viewObjects.count > 0 {
                
                guard let view = viewObjects[0] as? NSView else { return false }
                preferencesMainView = view
                self.addSubview(preferencesMainView!)
                
                preferencesMainView?.translatesAutoresizingMaskIntoConstraints = false
                preferencesMainView?.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
                preferencesMainView?.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
                preferencesMainView?.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
                preferencesMainView?.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
                //preferencesMainView?.centerXAnchor.constraint(equalTo: self.preferencesMainView!.centerXAnchor).isActive = true
                
                return true
            
            }   // <=== End of "if viewObjects.count > 0"
        
        }   // <=== End of "if Bundle.main.loadNibNamed(nibName, owner: self, topLevelObjects: &nibObjects)"
        
        return false
    
    }   // <=== End of "func load(fromNIBNamed nibName: String) -> Bool"

    
    func add(toView parentView: NSView) {
        
        parentView.addSubview(self)
        self.translatesAutoresizingMaskIntoConstraints = false
        self.leadingAnchor.constraint(equalTo: parentView.leadingAnchor).isActive = true
        self.trailingAnchor.constraint(equalTo: parentView.trailingAnchor).isActive = true
        self.topAnchor.constraint(equalTo: parentView.topAnchor).isActive = true
        self.bottomAnchor.constraint(equalTo: parentView.bottomAnchor).isActive = true
    
    }   // <=== End of "func add(toView parentView: NSView)"

}   // <=== End of "extension PreferencesLoadableView where Self: NSView"
