//
//  PreferencesViewController.swift
//  PopOverDatePickerTest
//
//  Created by jim kitchen on 2021-10-29.
//

import Cocoa

class PreferencesViewController: NSViewController, NSWindowDelegate {

    // ============================================================
    // MARK: - Identify the Application's "Outlets"
    // ============================================================
    
        /// Identify the "TabView" to display the separate views
        @IBOutlet weak var preferencesTabView: NSTabView!
    
    // ============================================================
    // MARK: - Identify the "Variables and the "Constants"
    // ============================================================
    
        /// Identify the "Views" for the "TabView"
        var preferencesFirstTabView: PreferencesFirstTabView?
        var preferencesSecondTabView: PreferencesSecondTabView?
    
    // ============================================================
    // MARK: - ViewDidLoad
    // ============================================================
        /// You can override this method to perform tasks to immediately follow the setting of
        /// the view property. Typically, your override would perform one-time instantiation and
        /// initialization of the contents of the view controller’s view. If you override this method,
        /// call this method on super at some point in your implementation in case a superclass
        /// also overrides this method. For a view controller originating in a nib file, this method
        /// is called immediately after the view property is set. For a view controller created
        /// programmatically, this method is called immediately after the loadView() method
        /// completes. The default implementation of this method does nothing.
    
        /// Called after the view controller’s view has been loaded into memory
        override func viewDidLoad() {
            super.viewDidLoad()
            /// Do any additional setup after loading the view.

            //print("Preferences view loading")
            
            /// Identify the location of the "Views" in the "TabView"
            guard let view1 = preferencesTabView.tabViewItem(at: 0).view, let view2 = preferencesTabView.tabViewItem(at: 1).view else {
                
                print("Preferences tabview failed to load, since the tabView is nil");
                
                /// Return gracefully since the "tabView" is emprty or "nil"
                return
                
            }   //  <=== End of "guard let view1 = "
            
            
            /// Add the "Views" to the "TabView"
            preferencesFirstTabView = PreferencesFirstTabView()
            preferencesFirstTabView?.add(toView: view1)
            
            preferencesSecondTabView = PreferencesSecondTabView()
            preferencesSecondTabView?.add(toView: view2)
            
            
        }   // <=== End of "override func viewDidLoad()"


    
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
    //  MARK: - VIEW WILL APPEAR
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
        /// Called after the view controller’s view is loaded into memory is about to be added to the view hierarchy in the window
        /// You can override this method to perform tasks prior to a view controller’s view getting added to view hierarchy, such as setting the view’s highlight color. This method is called when:
        ///   1.  The view is about to be added to the view hierarchy of the view controller.
        ///   2. The view controller’s window is about to become visible, such as coming to the front or becoming unhidden.
        /// If you override this method, call this method on super at some point in your implementation in case a superclass also overrides this method.
        /// The default implementation of this method does nothing.
    
        override func viewWillAppear() {
            super.viewWillAppear()
        }   //  <=== End of "override func viewWillAppear()"
    
    // MARK: ========================================================================================================================
    // MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // MARK: ========================================================================================================================
    // MARK: - VIEW DID APPEAR
    // MARK: ========================================================================================================================
    // MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    // MARK: ========================================================================================================================
    /// This method is called after the completion of any drawing and animations involved in the initial appearance of the view. You can override this method to perform tasks
    /// appropriate for that time, such as work that should not interfere with the presentation animation, or starting an animation that you want to begin after the view appears.
    ///
    /// If you override this method, call this method on super at some point in your implementation in case a superclass also overrides this method.
    /// The default implementation of this method does nothing.
    
          override func viewDidAppear() {
              super.viewDidAppear()
          } //  <=== End of "override func viewDidAppear()"
 
    
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
    //  MARK: - VIEW WILL DISAPPEAR
    //  MARK: ========================================================================================================================
    //  MARK: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //  MARK: ========================================================================================================================
    /// You can override this method to perform tasks prior to a view controller’s view getting added to view hierarchy, such as setting the view’s highlight color. This method is called when:
    ///  1. The view is about to be added to the view hierarchy of the view controller.
    ///  2. The view controller’s window is about to become visible, such as coming to the front or becoming unhidden.
    /// If you override this method, call this method on super at some point in your implementation in case a superclass also overrides this method.
    /// The default implementation of this method does nothing.

        override func viewWillDisappear() {
                super.viewWillDisappear()
        }   //  <=== End of "override func viewWillDisappear()"
    
    
    // ============================================================
    // MARK: - RepresentedObject
    // ============================================================
    /// This property retains the object you provide to it; it does not copy it. In another words,
    /// a view controller has a to-one relationship with its represented object and does not
    /// own it as an attribute. The representedObject property is key-value coding and
    /// key-value observing compliant. When you use the represented object as the file's
    /// owner of a nib file, you can bind controls to the file's owner using key paths that
    /// start with the string representedObject.
        
        override var representedObject: Any? {
            didSet {
                /// Update the view, if already loaded.
            }
        }   //  <=== End of "override var representedObject: Any?"
    // ============================================================
    // ============================================================
    
    
}   //  <=== End of "class ViewController: NSViewController"

