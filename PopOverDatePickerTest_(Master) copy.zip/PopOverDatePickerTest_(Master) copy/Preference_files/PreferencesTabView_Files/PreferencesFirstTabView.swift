//
//  PreferencesFirstTabView.swift
//  PopOverDatePickerTest
//
//  Created by jim kitchen on 2021-10-29.
//

import Cocoa
import Foundation
import AppKit
import SwiftUI
import UserNotifications

class PreferencesFirstTabView: NSView, PreferencesLoadableView, NSUserNotificationCenterDelegate {
    
    // ============================================================
    // ============================================================
    // MARK: - Identify the Application's "Outlet Properties"
    // ============================================================
    // ============================================================
    
        @IBOutlet weak var colorWellLabel: NSTextField!
        
        @IBOutlet weak var colorWell: NSColorWell!
        
        @IBOutlet weak var thePreferencesSystemModeRadioButton: NSButton!
        @IBOutlet weak var thePreferencesDarkModeRadioButton: NSButton!
        @IBOutlet weak var thePreferencesLightModeRadioButton: NSButton!
        
        @IBOutlet weak var thePreferencesSystemModeButtonBox: NSBox!
        @IBOutlet weak var thePreferencesSystemModeButtonBoxLabel: NSTextField!
        
    // ============================================================
    // ============================================================
    // MARK: - Properties
    // ============================================================
    // ============================================================
        
        var preferencesMainView: NSView?
        
        var theSelectedRadio: NSButton?
        
        var systemMode = "system"
        
    /// Create a copy of "UserDefaults.standard"
        let theLotto649UserDefaults = UserDefaults.standard
        
        @State private var radioSelected = 0
        
    // ============================================================
    // ============================================================
    // MARK: - Init
    // ============================================================
    // ============================================================
        
        init() {
            
            super.init(frame: NSRect.zero)
            
            if load(fromNIBNamed: "PreferencesFirstTabView") {
                
                /// Set the "First TabView Preference Constraints" Programmatically.
                applyConstraints()
                
                /// Set the "Colour Picker ColorWell to a Default Colour"
                colorWell?.color = NSColor.blue
                
                /// Set the "System Selection Buttons" defaults.
                loadSettings()
                
        // ============================================================
        // MARK: Check to see whether Default Button Key Exists
        // ============================================================
                
                /// You must check to see whether the selected default key is present in "User Defaults"
                /// or else you will get false as default value and your button will disabled only
                if isTheDefaultButtonKeyPresentInTheUserDefaults(key: "theUserWantsToStoreThisSelectedButton") {
                    
                    /// Initializer for conditional binding "MUST HAVE AN OPTIONAL TYPE", and not a "Bool' (as the line of code below shows)
                    //guard let theUserSelectedDefaultButton = UserDefaults.standard.bool(forKey: "theUserWantsToStoreThisSelectedButton")  else { return }
                    
                    
                    /// Identify the "theUserSelectedDefaultButton"
                    let theUserSelectedDefaultButton = UserDefaults.standard.bool(forKey: "theUserWantsToStoreThisSelectedButton")
                    /// Enable the "thePreferencesSystemModeRadioButton"
                    thePreferencesSystemModeRadioButton?.isEnabled = theUserSelectedDefaultButton
                    
                    /// Determine whether the "BOOL" result is "TRUE or FALSE"
                    //print("The Selected Button:", theUserSelectedDefaultButton)
                    
                } else if isTheDefaultButtonKeyPresentInTheUserDefaults(key: "theUserWantsToStoreThisSelectedButton") {
                    
                    /// Identify the "theUserSelectedDefaultButton"
                    let theUserSelectedDefaultButton = UserDefaults.standard.bool(forKey: "theUserWantsToStoreThisSelectedButton")
                    /// Enable the "thePreferencesDarkModeRadioButton"
                    thePreferencesDarkModeRadioButton?.isEnabled = theUserSelectedDefaultButton
                    
                } else if isTheDefaultButtonKeyPresentInTheUserDefaults(key: "theUserWantsToStoreThisSelectedButton") {
                    
                    /// Identify the "theUserSelectedDefaultButton"
                    let theUserSelectedDefaultButton = UserDefaults.standard.bool(forKey: "theUserWantsToStoreThisSelectedButton")
                    /// Enable the "thePreferencesLightModeRadioButton"
                    thePreferencesLightModeRadioButton?.isEnabled = theUserSelectedDefaultButton
                
                }   //  End of (if isTheDefaultButtonKeyPresentInTheUserDefaults(key: "theUserWantsToStoreThisSelectedButton"))
                
        // ============================================================
        // MARK: Check to see whether Default Button Key Exists Function
        // ============================================================
        
                /// Check to see if the key is present or not and not equal to "NIL"
                func isTheDefaultButtonKeyPresentInTheUserDefaults(key: String) -> Bool {
                /// We can use the "if statement" to check that the optional is not "nil" and then force unwrap the optional safely, as shown below.
                    return UserDefaults.standard.object(forKey: key) != nil
                }    //  <=== End of ( func isTheDefaultButtonKeyPresentInTheUserDefaults(key: String) -> Bool )
            
            } //  <=== End of ( if load(fromNIBNamed: "PreferencesFirstTabView") )
            
        }   //  <=== End of ( init() )

    
    // ============================================================
    // ============================================================
    // MARK: - Required Init
    // ============================================================
    // ============================================================
    
        required init?(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
        }
    

    // ============================================================
    // ============================================================
    //  MARK: - handleColorPicker Selection
    // ============================================================
    // ============================================================
    
        @IBAction func handleColorPick(_ sender: NSColorWell) {
            
            /// Show an "Alert" to warn the User the "Deafult Values" could be "Reset"
            alertTheUserToKeepColorWellActiveToChangeTableViewBackgroundColour()
            
            //print("Calling handleColorPick action")
            
            /// Display that color panel using the activate command.
            colorWell.activate(true)
            /// Removed this "selector" action call since it stopped "handleColorPick" from being called another time.
            //colorWell.action = #selector(changeTextColor(_:))
            
            /// Identify the "selected Colour" from the "colorWell"
            let theSelectedColourPickerColour = colorWell.color
            
            /// Moved this code to this location , originally located above.
            /// Change the "ColorWellLabel Colour" to the selected colour.
            colorWellLabel.textColor = colorWell.color
            
            //print("The Selected Color:", colorWell.color)
        
    //  ============================================================
    //  ============================================================
    //  MARK: - Issue a notification for "handleColorPick" action
    /// The "handleColorPick" notification is published using "DispatchQueue"
    /// with a delay.
    /// The information will update the "Lotto649DataView" to update the "TableView'
    //  ============================================================
    //  ============================================================
        
            /// qos <=== This means quality of service with where, when, and how it occurs
            /// Use the "Background" thread
            DispatchQueue.global(qos: .background).async {
            
                /// Return to  the "Main" thread after a small time delay.
                //DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { // <=== executes after a two (2) second delay with "2.0"
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { // <=== executes after a quarter second delay with "0.25"
                
                // Create a notifiction for the "MAIN DATABASE TABLEVIEW"
                    /// Post this notification containing the "theSelectedColourPickerColour" identified information object
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "theRealTimeSelectedColourNotification"),
                                                    object: theSelectedColourPickerColour)

                }   //  <=== End of "DispatchQueue.main.asyncAfter(deadline: .now() + 0.10)"
        
            }   //  <=== End of "DispatchQueue.global(qos: .background).async"
        
           
            do {
                
                // Create a "DEFAULT SETTING" for the "MAIN LOTTO NUMBERS MAIN DATABASE TABLEVIEW"
                let theColorToSetAsTheMainDataBaseTableViewDefault: NSColor = theSelectedColourPickerColour
                let data = try NSKeyedArchiver.archivedData(withRootObject:theColorToSetAsTheMainDataBaseTableViewDefault,requiringSecureCoding:true)
                
                UserDefaults.standard.set(data, forKey: "theUserSelectedDefaultColor")
                //print("The SELECTED COLOUR to Set as The DEFAULT SAVED COLOUR FOR THE MAIN DATABASE TABLEVIEW =", theColorToSetAsTheMainDataBaseTableViewDefault)
                
            } catch {
               print(error)
            }
            
        
        }   //  <=== End of "@IBAction func handleColorPick(_ sender: NSColorWell)"
 

    
    // ============================================================
    // ============================================================
    //  MARK: - Custom Methods
    // ============================================================
    // ============================================================
    
        func loadSettings() {
            
            /// Test to see whether the"User Default Value" exists first to prevent a possible system crash.
            if let thePreferredSystem = UserDefaults.standard.value(forKey: "thePreferencesSystemMode") as? String {
                
                /// Check the default setting for the previous saved "SystemMode" selection.
                if thePreferredSystem == "thePreferencesSystemModeSelection" {
                    
                    //print("thePreferencesSystemModeSelection is preferred selection")
                    
                    if ((thePreferencesSystemModeRadioButton) != nil) == true {
                        thePreferencesSystemModeRadioButton.state = NSControl.StateValue.on
                    } else {
                        //print("The BOOL states the thePreferencesSystemModeRadioButton is false")
                    }
                        
                } else if thePreferredSystem == "thePreferencesDarkModeSelection" {
                    
                    //print("thePreferencesDarkModeSelection is preferred selection")
                    
                    if ((thePreferencesDarkModeRadioButton) != nil) == true {
                        thePreferencesDarkModeRadioButton.state = NSControl.StateValue.on
                    } else {
                        //print("The BOOL states the thePreferencesDarkModeRadioButton is false")
                    }
                
                } else if thePreferredSystem == "thePreferencesLightModeSelection" {
                    
                    //print("thePreferencesLightModeSelection is preferred selection")
                    
                    if ((thePreferencesLightModeRadioButton) != nil) == true {
                        thePreferencesLightModeRadioButton.state = NSControl.StateValue.on
                    } else {
                        //print("The BOOL states the thePreferencesLightModeRadioButton is false")
                    }
                
                }  //  <=== End of "if  thePreferredSystem == "thePreferencesSystemModeSelection""
            
            } else {
                
                /// Return and exit gracefully if the "User Default" does not exist.
                return
                
            }   //  <=== End of "if let thePreferredSystem = UserDefaults.standard.value"
            
            
        }   //  <=== End of "func loadSettings()"
 
    
    // ============================================================
    // ============================================================
    //  MARK: - Retrieve Colour Settings
    // ============================================================
    // ============================================================
    
        func retrieveColorSettings() {
            
            /// Test to see whether the"User Default Value" exists first to prevent a possible systme crash.
            if let result = UserDefaults.standard.value(forKey: "theUserSelectedDefaultColor") as? Data {
                
                let theSavedColourData = try! NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(result ) as? NSColor
                //print("The Retrieved Saved Selected Color In Preference First TabView =", theSavedColourData!)
                
            //  ============================================================
            //  ============================================================
            //  MARK: - Issue a notification "to update "DEFAULT" background colour"
            /// The "handleColorPick" notification is published using "DispatchQueue" with a delay.
            /// The information will update the "Lotto649DataView" to update the "TableView'
            //  ============================================================
            //  ============================================================
                
                /// qos <=== This means quality of service with where, when, and how it occurs
                /// Use the "Background" thread
                DispatchQueue.global(qos: .background).async {
                /// Return to  the "Main" thread after a small time delay.
                    //DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { // <=== executes after a two (2) second delay with "2.0"
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { // <=== executes after a (1/4) second delay with "0.25"
                    
                        // Notification for the "MAIN DATABASE TABLEVIEW"
                        /// Post this notification containing the "theSelectedColourPickerColour" identified information object
                        //NotificationCenter.default.post(name: NSNotification.Name(rawValue: "theMainDataBaseTableViewDefaultColourChangeNotice"),
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "theDefaultColourChangeNotice"),
                                                    object: theSavedColourData!)
                    
                    }   //  <=== End of "DispatchQueue.main.asyncAfter(deadline: .now() + 0.10)"
                
                }   //  <=== End of (DispatchQueue.global(qos: .background).async)
                
            } else {
                
                print("nothing here")
                
                /// Return and exit gracefully if the "User Default" does not exist.
                return
                
            }   //  <=== End of (if let result = UserDefaults.standard.value(forKey: "theUserSelectedDefaultColor") as? Data)
            
            
        }   //  <=== End of "func retrieveColorSettings()"
    
  
    // ============================================================
    // ============================================================
    //  MARK: - handleSystemModePreference Selection
    // ============================================================
    // ============================================================
    
        @IBAction func handleSystemModePreferenceSelection(_ sender: NSButton) {
            
            /// NOTE: Each (BUTTON) must be connected to the (IBAction) to perform together as a group.
            
            /// Set the "Buttons Visibility Defaults"
            thePreferencesSystemModeRadioButton.isHidden = false
            thePreferencesDarkModeRadioButton.isHidden = false
            thePreferencesLightModeRadioButton.isHidden = false
            
            /// This "Conditional Cast" from "NSButton to NSButton" always succeeds.
            /// The code produces a message to that effect.
            //guard let radio = sender as? NSButton else { return }
            
            /// Simple reassignment instead of the code above.
            let radio = sender
            
            /// Print the "Button's Title when selected.
            //print("Selected radio button:", radio.title)
            
            theSelectedRadio = thePreferencesSystemModeRadioButton
            
        // ============================================================
        //  MARK: - Choose System Mode Button
        // ============================================================
            
            if radio == thePreferencesSystemModeRadioButton {
                
                //print("Chose thePreferencesSystemModeRadioButton")
                
                /// Assigned to "thePreferencesSystemModeSelection" button.
                NSApp.appearance = nil
                systemMode = "system"
                
                /// User chose the "thePreferencesSystemModeSelection" button.
                /// Save the selection to "User Defaults".
                UserDefaults.standard.setValue("thePopoverSystemModeSelection", forKey: "thePreferencesSystemMode")
                /// Send "Notification" the "Selection" did change.
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "didChangeSystemModeSelection"),
                                                object: "thePreferencesSystemModeSelection")
                
                /// Identify the "Buttons Assigned Tag"
                if radio.tag == 0 {
                    //print("Button Tag is Zero (0)")
                }
                
                /// Save the button assignment in "User Defaults"
                theLotto649UserDefaults.set(true, forKey: "theUserWantsToStoreThisSelectedButton")
                //print("thePreferencesSystemModeRadioButton selected")
                
        // ============================================================
        //  MARK: - Choose Dark Mode Button
        // ============================================================
                
            } else if radio == thePreferencesDarkModeRadioButton {
                
                //print("Chose thePreferencesDarkModeRadioButton")
                
                /// Assigned to "thePreferencesDarkModeSelection" button.
                NSApp.appearance = NSAppearance(named: .darkAqua)
                systemMode = "dark"
                
                /// User chose the "thePreferencesDarkModeSelection" button.
                /// Save the selection to "User Defaults".
                UserDefaults.standard.setValue("thePreferencesDarkModeSelection", forKey: "thePreferencesSystemMode")
                /// Send "Notification" the "Selection" did change.
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "didChangeSystemModeSelection"),
                                                object: "thePreferencesDarkModeSelection")
                
                /// Identify the "Buttons Assigned Tag"
                if radio.tag == 1 {
                    //print("Button Tag is One (1)")
                }
                
                /// Save the button assignment in "User Defaults"
                theLotto649UserDefaults.set(true, forKey: "theUserWantsToStoreThisSelectedButton")
                //print("thePreferencesDarkModeRadioButton selected")
                
        // ============================================================
        //  MARK: - Choose Light Mode Button
        // ============================================================
                
            } else if radio == thePreferencesLightModeRadioButton {
                
                //print("Chose thePreferencesLightModeRadioButton")
                
                /// Assigned to "thePreferencesLightModeSelection" button.
                NSApp.appearance = NSAppearance(named: .aqua)
                systemMode = "light"
                
                /// User chose the "thePreferencesLightModeSelection" button.
                /// Save the selection to "User Defaults".
                UserDefaults.standard.setValue("thePreferencesLightModeSelection", forKey: "thePreferencesSystemMode")
                /// Send "Notification" the "Selection" did change.
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "didChangeSystemModeSelection"),
                                                object: "thePreferencesLightModeSelection")
                
                /// Identify the "Buttons Assigned Tag"
                if radio.tag == 2 {
                    //print("Button Tag is Two (2)")
                }
                
                /// Save the button assignment in "User Defaults"
                theLotto649UserDefaults.set(true, forKey: "theUserWantsToStoreThisSelectedButton")
                //print("thePreferencesLightModeRadioButton selected")
                
            }   //  <=== End of "if radio == thePreferencesSystemModeRadioButton"
            
        }   //  <=== End of "@IBAction func handleSystenModePreference(_ sender: Any)"
    
 
    // ============================================================
    //  MARK: - System Mode Enum
    // ============================================================
    
        enum AppAppearance: String {
            case dark
            case light
            case system
        }
    
    // ============================================================
    // MARK: - Constraints
    // ============================================================
    
        fileprivate func applyConstraints() {
            
            //print("Applying Initial First TabView Preference View Constraints")
            
            guard let preferencesMainView = preferencesMainView else { return }
            
            /// theColorWelllabelConstraints
            colorWellLabel?.translatesAutoresizingMaskIntoConstraints = false
            colorWellLabel?.leftAnchor.constraint(equalTo: preferencesMainView.leftAnchor, constant: 20).isActive = true
            colorWellLabel?.topAnchor.constraint(equalTo: preferencesMainView.topAnchor, constant: 174.0).isActive = true
            colorWellLabel?.widthAnchor.constraint(equalToConstant: 110.0).isActive = true
            colorWellLabel?.heightAnchor.constraint(equalToConstant: 16.0).isActive = true
            
            /// theColorWellConstraints
            colorWell?.translatesAutoresizingMaskIntoConstraints = false
            colorWell?.leftAnchor.constraint(equalTo: preferencesMainView.leftAnchor, constant: 20).isActive = true
            colorWell?.topAnchor.constraint(equalTo: preferencesMainView.topAnchor, constant: 200.0).isActive = true
            colorWell?.widthAnchor.constraint(equalToConstant: 180.0).isActive = true
            colorWell?.heightAnchor.constraint(equalToConstant: 180.0).isActive = true
            
            /// thePreferencesSystemModeButtonBoxLabelConstraints
            thePreferencesSystemModeButtonBoxLabel?.translatesAutoresizingMaskIntoConstraints = false
            thePreferencesSystemModeButtonBoxLabel?.leftAnchor.constraint(equalTo: preferencesMainView.leftAnchor, constant: 20).isActive = true
            thePreferencesSystemModeButtonBoxLabel?.topAnchor.constraint(equalTo: preferencesMainView.topAnchor, constant: 24.0).isActive = true
            thePreferencesSystemModeButtonBoxLabel?.widthAnchor.constraint(equalToConstant: 192.0).isActive = true
            thePreferencesSystemModeButtonBoxLabel?.heightAnchor.constraint(equalToConstant: 20.0).isActive = true
            
            /// thePreferencesSystemModeButtonBoxConstraints
            thePreferencesSystemModeButtonBox?.translatesAutoresizingMaskIntoConstraints = false
            thePreferencesSystemModeButtonBox?.leftAnchor.constraint(equalTo: preferencesMainView.leftAnchor, constant: 20).isActive = true
            thePreferencesSystemModeButtonBox?.topAnchor.constraint(equalTo: preferencesMainView.topAnchor, constant: 52.0).isActive = true
            thePreferencesSystemModeButtonBox?.widthAnchor.constraint(equalToConstant: 180.0).isActive = true
            thePreferencesSystemModeButtonBox?.heightAnchor.constraint(equalToConstant: 106.0).isActive = true
            
        }   //  <=== End of "fileprivate func applyConstraints()"
        
        
    }   //  <=== End of "class Lotto649DataView: NSView"


//  ============================================================
//  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  ============================================================
//  MARK: - "alertTheUserToKeepColorWellActiveToChangeTableViewBackgroundColour"
//  ============================================================
//  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  ============================================================

    func alertTheUserToKeepColorWellActiveToChangeTableViewBackgroundColour() {
        
        //print("say hello")
        
        /// Store the "suppression state" in "userDefaults" to "NOT ASK THIS QUESTION AGAIN"
        let userDefaultsKey = "dontAskToAlertTheUserToKeepColorWellActive"
        
        /// Check to see whether the "User" answered the question to not see the following code again
        if UserDefaults.standard.bool(forKey: userDefaultsKey) == false {
            
            let alert = NSAlert()
            alert.messageText = "Keep the ColorWell Active!!!"
            alert.informativeText = "The ColorWell Must be active to change the TableView Background Colours."
            
            alert.alertStyle = .critical
            alert.showsSuppressionButton = true
            alert.suppressionButton?.title = "Don't ask me again!"
            
            alert.addButton(withTitle: "OK")
            alert.addButton(withTitle: "Cancel")
            
            let response = alert.runModal()
            
            /// Turn off the "ALERT" with "User Default Preferences" setting.
            if let supress = alert.suppressionButton {
                
                let state = supress.state
                
                switch state {
                    case NSControl.StateValue.on:
                    UserDefaults.standard.set(true, forKey: userDefaultsKey)
                    default: break
                    
                }   //  <=== End of "switch state"
                
            }   //  <=== End of "if let supress = alert.suppressionButton"
            
            
        // ============================================================
        // MARK: - User chose "OK"
        // ============================================================
            
            /// Cancel Button is set to be the "Default" selection.
            if response == .alertFirstButtonReturn {
                
                /// Do nothing
                //print("alertFirstButtonCancel (OK Button)")
                
                /// Bail and "Return" gracefully
                /// Activating thie following code causes the "Colour Choice" to  falter. (Disabled for now...)
                //return
                
            } else {
                
        // ============================================================
        // MARK: - User chose "Cancel Button""
        // ============================================================
                
                /// Do nothing
                //print("alertSecondButtonCancel (Cancel Button)")
                
            }   // <=== End of "if response == .alertFirstButtonReturn"
            
        }   //  <=== End of "if UserDefaults.standard.bool(forKey: userDefaultsKey) == false"
            
            /// Bail and "Return" gracefully
            return
            
    }   //  <=== End of "alertTheUserAboutChangingTheDefaultPreferences()"

