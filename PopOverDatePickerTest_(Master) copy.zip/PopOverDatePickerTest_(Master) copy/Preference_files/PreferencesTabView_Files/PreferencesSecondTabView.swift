//
//  PreferencesSecondTabView.swift
//  PopOverDatePickerTest
//
//  Created by jim kitchen on 2021-10-29.
//

import Cocoa
import Foundation
import AppKit
import SwiftUI
import UserNotifications

class PreferencesSecondTabView: NSView, PreferencesLoadableView, NSUserNotificationCenterDelegate, NSApplicationDelegate {

    
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
//  MARK: - IDENTIFY THE APPLICATIONS'S "OUTLET PROPERTIES'
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
    
    @IBOutlet var DefaultSettingTitleLabel: NSTextField!
    
    /// Second Tab Preference Control Buttons
    @IBOutlet var ResetApplicationDefaultPreferencesButton: NSButton!
    /// The note below the (CheckBox)
    @IBOutlet var ResetCheckBoxNoteText: NSTextField!
    
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
//  MARK: - PROPERTIES
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
    
        var preferencesMainView: NSView?
    
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
//  MARK: - INIT
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
        
        init() {
            
            super.init(frame: NSRect.zero)
            
            if load(fromNIBNamed: "PreferencesSecondTabView") {
                
                /// Identify the "Web Page" from "User Defaults.'
                //let theWebPage = UserDefaults.standard.string(forKey: "NewDefaultLottoWebPageAddress")
                /// Print the "Web Page."
                //print(theWebPage!)
                
                /// Set the "Second TabView Preference Constraints" Programmatically.
                applyConstraints()
                
            }   //  <=== End of "if load(fromNIBNamed: "PreferencesSecondTabView")"
            
        }   //  <=== End of "init()"
        
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
//  MARK: - REQUIRED INIT
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====

        required init?(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
        }

/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
//  MARK: - IBACTION METHODS
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====

    // ============================================================
    /// User wants to "Reset the User Defaults"
    // ============================================================
    
    @IBAction func ChangeApplicationDefaultPreferences(_ sender: NSButton) {
    
        /// Verify the whether the "Defaults Checkbox" is "ON / OFF".
        /// The "Checkbox" is "OFF" by default in "Interface Builder".
        if ResetApplicationDefaultPreferencesButton.state == NSControl.StateValue.on {
            //print("Reset User Defaults Checkbox is checked")
            /// Show an "Alert" to warn the User the "Default Values" could be "Reset"
            alertTheUserAboutChangingTheDefaultPreferences()
        }
        
        /// Toggle the Checkbox to be "OFF" after the selection is made.
        ResetApplicationDefaultPreferencesButton.state = NSControl.StateValue.off // <=== Set to "OFF" to uncheck
        
    }   //  <=== End of "@IBAction func ChangeApplicationDefaultPreferences(_ sender: NSButton)"



/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
//  MARK: - CONSTRAINTS
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
    
        fileprivate func applyConstraints() {
            
            //print("Applying Initial Second TabView Preference View Constraints")
            
            guard let preferencesSecondTabMainView = preferencesMainView else { return }
            
            /// the Default Settings Title
            DefaultSettingTitleLabel?.translatesAutoresizingMaskIntoConstraints = false
            DefaultSettingTitleLabel?.leftAnchor.constraint(equalTo: preferencesSecondTabMainView.leftAnchor, constant: 20).isActive = true
            DefaultSettingTitleLabel?.topAnchor.constraint(equalTo: preferencesSecondTabMainView.topAnchor, constant: 20.0).isActive = true
            DefaultSettingTitleLabel?.widthAnchor.constraint(equalToConstant: 200.0).isActive = true
            DefaultSettingTitleLabel?.heightAnchor.constraint(equalToConstant: 26.0).isActive = true
            
            
            /// the ResetApplicationDefaultPreferencesButton
            ResetApplicationDefaultPreferencesButton?.translatesAutoresizingMaskIntoConstraints = false
            ResetApplicationDefaultPreferencesButton?.leftAnchor.constraint(equalTo: preferencesSecondTabMainView.leftAnchor, constant: 20).isActive = true
            ResetApplicationDefaultPreferencesButton?.topAnchor.constraint(equalTo: preferencesSecondTabMainView.topAnchor, constant: 90.0).isActive = true
            ResetApplicationDefaultPreferencesButton?.widthAnchor.constraint(equalToConstant: 280.0).isActive = true
            ResetApplicationDefaultPreferencesButton?.heightAnchor.constraint(equalToConstant: 18.0).isActive = true
            
            
            /// the ResetApplicationDefaultPreferencesButton
            ResetCheckBoxNoteText?.translatesAutoresizingMaskIntoConstraints = false
            ResetCheckBoxNoteText?.leftAnchor.constraint(equalTo: preferencesSecondTabMainView.leftAnchor, constant: 40).isActive = true
            ResetCheckBoxNoteText?.topAnchor.constraint(equalTo: preferencesSecondTabMainView.topAnchor, constant: 116.0).isActive = true
            ResetCheckBoxNoteText?.widthAnchor.constraint(equalToConstant: 430.0).isActive = true
            ResetCheckBoxNoteText?.heightAnchor.constraint(equalToConstant: 16.0).isActive = true
            
            
        }   //  <=== End of "fileprivate func applyConstraints()"
        
        
    }   //  <=== End of "class Lotto649DataView: NSView"



/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
//  MARK: - ALERT USER ABOUT CHANGING DEFAULT PREFERENCES FUNCTION
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====
/// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/// ====-----------------------------------------------------------------------------------------------------------------------------------------------------------====

    func alertTheUserAboutChangingTheDefaultPreferences() {
        
        /// Store the "suppression state" in "userDefaults" to "NOT ASK THIS QUESTION AGAIN"
        let userDefaultsKey = "dontAskToAlertTheUserToChangeTheDefaultPreferences"
        
        /// Check to see whether the "User" answered the question to not see the following code again
        if UserDefaults.standard.bool(forKey: userDefaultsKey) == false {
            
            let alert = NSAlert()
            alert.messageText = "Please Review Your Selection!!!"
            alert.informativeText = "You are about to reset the User Preferences."
            
            alert.alertStyle = .critical
            alert.showsSuppressionButton = true
            alert.suppressionButton?.title = "Don't ask me again!"
            
            /// Disabled code
            //alert.addButton(withTitle: "OK")
            //alert.addButton(withTitle: "Cancel")
            
            /// Change the "Selection"
            alert.addButton(withTitle: "Cancel")
            alert.addButton(withTitle: "Reset Defaults")
            
            let response = alert.runModal()
            
            /// Turn off the "ALERT" with "User Default Preferences" setting.
            if let supress = alert.suppressionButton {
                
                let state = supress.state
                
                switch state {
                    case NSControl.StateValue.on:
                    UserDefaults.standard.set(true, forKey: userDefaultsKey)
                    default: break
                    
                }   //  <=== End of "switch state"
            
                
            }   //  <=== End of "if let supress = alert.suppressionButton"
            
            
        // ============================================================
        // MARK: - User chose to "Cancel"
        // ============================================================
            
            /// Cancel Button is set to be the "Default" selection.
            if response == .alertFirstButtonReturn {
                
                /// Do nothing
                //print("alertSecondButtonCancel (CANCEL Button)")
                
                /// Bail and "Return" gracefully
                /// Activating thie following code causes the "Colour Choice" to  falter. (Disabled for now...)
                //return
                
            } else {
                
        // ============================================================
        // MARK: - User chose to "Reset the Application Defaults"
        // ============================================================
                
                /// Send a notification to "Add649NumbersController" to "Reset the Application's Defaults"
                /// The reset code conditional is located in the "viewDidLoad" code.
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "theUserWantsToResetTheApplicationDefaults"),
                                                    object: nil)
                
                //print("alertFirstButtonReturn (RESET Button)")
                
            }   // <=== End of "if response == .alertFirstButtonReturn"
            
        }   //  <=== End of "if UserDefaults.standard.bool(forKey: userDefaultsKey) == false"
        
        /// Bail and "Return" gracefully
        return
        
    }   //  <=== End of "alertTheUserAboutChangingTheDefaultPreferences()"



// ====-----------------------------------------------------------------------------====
// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// ====-----------------------------------------------------------------------------====
//  MARK: - "alertTheUserTheWebPageTextFieldIsEmpty"
//  MARK: - (with disable code)
/// Employ "User Default Suppression Code."
// ====-----------------------------------------------------------------------------====
// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// ====-----------------------------------------------------------------------------====

      func alertTheUserWebPageTheTextFieldIsEmpty() {
          
          /// Store the "suppression state" in "userDefaults" to "NOT ASK THIS QUESTION AGAIN"
          let userDefaultsKey = "dontAskToAlertTheUserTheWebPageTextFieldIsEmpty"
          
          /// Check to see whether the "User" answered the question to not see the following code again
          if UserDefaults.standard.bool(forKey: userDefaultsKey) == false {
              
              let alert = NSAlert()
              alert.messageText = "Busted!!!"
              alert.informativeText = "The Web Page textField is empty."
              
              alert.alertStyle = .critical
              alert.showsSuppressionButton = true
              alert.suppressionButton?.title = "Don't bother me again with this alert!"
              
              alert.addButton(withTitle: "OK")
              alert.addButton(withTitle: "Cancel")
              
              let response = alert.runModal()
              
              /// Turn off the "ALERT" with "User Default Preferences" setting.
              if let supress = alert.suppressionButton {
                  
                  let state = supress.state
                  
                  switch state {
                      case NSControl.StateValue.on:
                      UserDefaults.standard.set(true, forKey: userDefaultsKey)
                      default: break
                      
                  }   //  <=== End of "switch state"
                  
              }   //  <=== End of "if let supress = alert.suppressionButton"
              
              if response == .alertFirstButtonReturn {
                  
                  print("\n alertFirstButtonReturn (OK Button)")
                  
              } else {
                  
                  print("Use default values")
                  
              }   // <=== End of "if response == .alertFirstButtonReturn"
              
              
          }   //  <=== End of "if UserDefaults.standard.bool(forKey: userDefaultsKey) == false"
          
            /// Bail and "Return" gracefully
            return
            
      }   // <=== End of "func alertTheUserTheTextFieldIsEmpty()"
